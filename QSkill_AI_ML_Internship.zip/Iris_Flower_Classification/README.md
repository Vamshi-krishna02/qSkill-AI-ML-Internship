# QSkill Task 1: Iris Flower Classification

## Objective
Classify iris flowers into Setosa, Versicolor, and Virginica using sepal and petal measurements.

## Dataset
The Iris dataset available through scikit-learn.

## Python Code
```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Load dataset
iris = load_iris()

X = pd.DataFrame(iris.data, columns=iris.feature_names)
y = iris.target

print(X.head())
print("Classes:", iris.target_names)

# Basic visualization
sns.pairplot(pd.DataFrame(iris.data, columns=iris.feature_names))
plt.show()

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Train model
model = LogisticRegression(max_iter=200)
model.fit(X_train, y_train)

# Prediction
y_pred = model.predict(X_test)

# Evaluation
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=iris.target_names))

print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))
```

## Steps
1. Load the Iris dataset.
2. Explore the numerical features.
3. Visualize relationships between features.
4. Split data into training and testing sets.
5. Train Logistic Regression.
6. Predict the test data.
7. Evaluate using accuracy, precision, recall, F1-score and confusion matrix.

## Expected Result
The model should classify the three Iris species with high accuracy on the test set.

## Conclusion
A simple Logistic Regression classifier can effectively classify Iris flowers using their sepal and petal measurements.
