# QSkill Task 3: House Price Prediction

## Objective
Predict house prices using numerical housing features such as size, location-related variables, and number of bedrooms.

## Dataset
Use a basic public housing dataset with numerical features. This project uses a CSV file named `housing.csv`.

## Python Code
```python
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# Load dataset
df = pd.read_csv("housing.csv")

print(df.head())
print(df.info())
print(df.describe())

# Select numerical columns
numeric_df = df.select_dtypes(include=["number"]).copy()

# Assume the target column is named 'price'
if "price" not in numeric_df.columns:
    raise ValueError("Please make sure the dataset contains a numerical 'price' column.")

X = numeric_df.drop("price", axis=1)
y = numeric_df["price"]

# Handle missing values
imputer = SimpleImputer(strategy="median")
X = pd.DataFrame(imputer.fit_transform(X), columns=X.columns)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Normalization
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train Linear Regression
model = LinearRegression()
model.fit(X_train_scaled, y_train)

# Prediction
y_pred = model.predict(X_test_scaled)

# Evaluation
mse = mean_squared_error(y_test, y_pred)
rmse = mse ** 0.5
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("Mean Squared Error:", mse)
print("RMSE:", rmse)
print("Mean Absolute Error:", mae)
print("R2 Score:", r2)

# Actual vs predicted plot
plt.scatter(y_test, y_pred)
plt.xlabel("Actual Price")
plt.ylabel("Predicted Price")
plt.title("Actual vs Predicted House Prices")
plt.show()
```

## Steps
1. Load a housing dataset.
2. Explore distributions and summary statistics.
3. Select numerical features.
4. Handle missing values.
5. Split data into training and testing sets.
6. Normalize the input features.
7. Train a Linear Regression model.
8. Predict house prices.
9. Evaluate using MSE, RMSE, MAE and R².

## Expected Result
The model produces numerical house-price predictions and can be evaluated using regression metrics.

## Conclusion
Linear Regression provides a beginner-friendly baseline for predicting house prices from numerical housing features.
