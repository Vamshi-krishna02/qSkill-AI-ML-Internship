# QSkill Task 2: Spam Mail Detector

## Objective
Build a classifier that distinguishes spam messages from legitimate (ham) messages using textual data.

## Dataset
SMS Spam Collection dataset (UCI) or an equivalent public spam/ham dataset.

## Python Code
```python
import pandas as pd
import re
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Download/use the SMS Spam Collection file named spam.csv.
# Expected columns: label and message
df = pd.read_csv("spam.csv", encoding="latin-1")

# Keep/rename the required columns when using the common SMS Spam Collection CSV format
if "v1" in df.columns and "v2" in df.columns:
    df = df[["v1", "v2"]]
    df.columns = ["label", "message"]

df = df.dropna()

# Text cleaning
def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-zA-Z\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

df["clean_message"] = df["message"].apply(clean_text)

# Convert labels
df["label_num"] = df["label"].map({"ham": 0, "spam": 1})

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    df["clean_message"],
    df["label_num"],
    test_size=0.2,
    random_state=42,
    stratify=df["label_num"]
)

# TF-IDF feature extraction
vectorizer = TfidfVectorizer(stop_words="english")
X_train_tfidf = vectorizer.fit_transform(X_train)
X_test_tfidf = vectorizer.transform(X_test)

# Train Naive Bayes model
model = MultinomialNB()
model.fit(X_train_tfidf, y_train)

# Prediction
y_pred = model.predict(X_test_tfidf)

# Evaluation
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=["Ham", "Spam"]))

print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))
```

## Steps
1. Load spam and ham messages.
2. Clean and lowercase text.
3. Convert messages into TF-IDF numerical features.
4. Split the dataset into training and testing data.
5. Train a Naive Bayes classifier.
6. Predict spam/ham labels.
7. Evaluate using accuracy, precision, recall and F1-score.

## Expected Result
The classifier should distinguish spam messages from normal messages with good accuracy.

## Conclusion
TF-IDF converts text into useful numerical features, while Naive Bayes provides a simple and effective baseline for spam detection.
